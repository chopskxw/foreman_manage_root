# foreman_manage_root
This is a simple puppet module designed to manage root using foreman parameters.
